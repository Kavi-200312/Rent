import React, { createContext, useState } from 'react';

export const CampaignContext = createContext();
import { v4 as uuidv4 } from 'uuid';

export const CampaignProvider = ({ children }) => {
  const [adminCampaigns, setAdminCampaigns] = useState([]);
  const [userCampaigns, setUserCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [newCampaign, setNewCampaign] = useState({
    campaign_title: '',
    campaign_description: '',
    start_date: '',
    end_date: '',
    campaign_address: '',
    budget: '',
    campaign_type: '',

  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewCampaign((prev) => ({ ...prev, [name]: value }));
  };

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  const handleToggleCampaignType = (type) => {
    setActiveCampaignType(type);
  };

  return (
    <CampaignContext.Provider
      value={{
        adminCampaigns,
        userCampaigns,
        loading,
        newCampaign,
        imageUrl,
        setImageUrl,
        handleChange,
        openModal,
        closeModal,
        handleToggleCampaignType,
        isModalOpen,
        setAdminCampaigns,
        setUserCampaigns,
        setLoading,
        setIsModalOpen,
      }}
    >
      {children}
    </CampaignContext.Provider>
  );
};
