import { createBrowserRouter } from "react-router-dom";

// Admin Components
import AdminLayout from "../Components/Admin/Layout/AdminLayout";
import AdminDashboard from "../Components/Admin/Pages/1.Dashboard/Dashboard";
import RegisteredUserList from "../Components/Admin/Pages/3.UserManagement/2.Registered/List/RegisteredUserList";
import GeneralUserList from "../Components/Admin/Pages/3.UserManagement/3.General/List/GeneralUserList";
import Request from "../Components/Admin/Pages/4.Request/Request";
import Queries from "../Components/Admin/Pages/5.Queries/Queries";
import AdminSignIn from "../Components/Admin/auth/AdminSignIn";
import Campaigns from "../Components/Admin/Pages/2.Campaigns/CampaignList/Campaigns";
// import CampaignsDetails from "../Components/Admin/Pages/2.Campaigns/CampaignList";

// User Components
import UserSignIn from "../Components/User/Auth/UserSignIn";
import UserSignUp from "../Components/User/Auth/UserSignUp";
import CampaignDashboard from "../Components/User/Pages/1.Dashboard/Dashboard";
import CampaignLayout from "../Components/User/Layout/UserLayout";
import GeneralUsersList from "../Components/User/Pages/3.General/List/GeneralUsersList";



// ?Landing
import NotFound from "../Components/Common/NotFound/notFound";
import Layout from "../Components/LandingPage/Layout/Layout";
import { Home } from "../Components/LandingPage/Pages/Home/Home";
import UserCampaigns from "../Components/User/Pages/2.Campaigns/CampaignList/UserCampaigns1";
import PaymentForm from "../Utils/PaymentForm";
import UserCampaigns1 from "../Components/User/Pages/2.Campaigns/CampaignList/UserCampaigns1";

const landingRoutes = [
  { index: true, element: <Home /> },
];

const adminRoutes = [
  { index: true, element: <AdminDashboard /> },
  { path: 'campaigns', element: <Campaigns /> },
  { path: 'registered-users', element: <RegisteredUserList /> },
  { path: 'general-users', element: <GeneralUserList /> },
  { path: 'requests', element: <Request /> },
  { path: 'queries', element: <Queries /> },
];

const userRoutes = [
  { index: true, element: <CampaignDashboard /> },
  {path: '/register-user/new-campaign', element: <UserCampaigns />,
    // children: [
    //   {
    //     path: "/register-user/new-campaign/campaign-management",
    //     element: <CampaignManager />
    //   }, {
    //     path: "/register-user/new-campaign/campaign",
    //     element: <Campaign />
    //   }]
  },
  { path: 'general-users', element: <GeneralUsersList /> },

]

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: landingRoutes,
  },
  {
    path: '/admin',
    element: <AdminLayout />,
    children: adminRoutes,
  },
  {
    path: '/register-user',
    element: <CampaignLayout />,
    children: userRoutes,
  },
  {
    path: '/admin/signin',
    element: <AdminSignIn />,
  },
  {
    path: '/signin',
    element: <UserSignIn />,
  },
  {
    path: '/signup',
    element: <UserSignUp />,
  },
  {
    path:"/transaction",
    element:<PaymentForm/>
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);
