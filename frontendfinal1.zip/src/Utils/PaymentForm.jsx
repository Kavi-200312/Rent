import React, { useRef, useState } from 'react';
import axiosInstance from './axiosInstance';

const PaymentForm = () => {
    const formRef = useRef(null);

    const [formData, setFormData] = useState({
        "platform": "web",
        "name": "",
        "mobilenumber": "",
        'email': "",
        "amount": "",
        'creditcardnumber': "",
        "registeredmobilenumber": ""
    });
    // const [isValid, setIsValid] = useState(true);

    const handleChange = (e) => {
        const { name, value } = e.target;
        // console.log(name);
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,

        }));
        // const regex = /^\+?[1-9]\d{1,14}$/;
        // setIsValid(regex.test(value));
        // pattern="^\+?[1-9]\d{1,14}$" // E.164 format
        // {!isValid && (
        //     <span style={{ color: 'red' }}>Invalid phone number format</span>
        // )}

    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(formData);
        try {
            await axiosInstance.post('/transaction/trans', formData, {timeout: 30000})
                .then((res) => {
                    console.log(res);
                    if (res.data.code === 200) {
                        let form = res.data.value;
                        console.log(form);
                        if (formRef.current) {
                            formRef.current.innerHTML = form;
                            const formElement = formRef.current.querySelector("form");
                            if (formElement) {
                                HTMLFormElement.prototype.submit.call(formElement);
                            }
                        }
                    }
                })
        } catch (error) {
            console.error('Payment Error:', error);
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <h2>Payment Form</h2>
                <div>
                    <label>
                        Name
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                        />
                    </label>
                </div>
                <div>
                    <label>
                        Email
                        <input
                            type="text"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                        />
                    </label>
                </div>
                <div>
                    <label>
                        Mobile Number
                        <input
                            type="text"
                            name="mobilenumber"
                            value={formData.mobilenumber}
                            onChange={handleChange}
                        />
                    </label>
                </div>
                <div>
                    <label>
                        Amount
                        <input
                            type="text"
                            name="amount"
                            value={formData.amount}
                            onChange={handleChange}
                        />
                    </label>
                </div>
                <div>
                    <label>
                        Last 4 digits of Credit Card Number
                        <input
                            type="text"
                            name="creditcardnumber"
                            value={formData.creditcardnumber}
                            onChange={handleChange}
                        />
                    </label>
                </div>
                <div>
                    <label>
                        Registered Mobile Number
                        <input
                            type="text"
                            name="registeredmobilenumber"
                            value={formData.registeredmobilenumber}
                            onChange={handleChange}
                        />
                    </label>
                </div>
                <button type="submit">Pay Now</button>
            </form>
            <div ref={formRef}></div>
        </div>
    );
};

export default PaymentForm;
