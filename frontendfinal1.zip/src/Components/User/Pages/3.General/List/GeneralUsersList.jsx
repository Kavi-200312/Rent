import React, { useEffect, useState } from 'react';

import axiosInstance from '../../../../../Utils/axiosInstance';
import './GeneralUsersList.css';

const GeneralUsersList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get('/user/gettr');
        setUsers(response.data.data);
        // console.log(users);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleAction = (userId) => {
    const user = users.find((u) => u._id === userId);
    setSelectedUser(user);
  };

  const closeModal = () => {
    setSelectedUser(null);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2>General User List</h2>
      <table>
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>No. of Campaigns</th>
            <th>Total Amount</th>
            {/* <th>Time</th> */}
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user._id}> {/* Use _id for unique key */}
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.mobilenumber}</td>
              <td>{user.campaigndetails ? user.campaigndetails.length : 0}</td>
              <td>{user.amount}</td>
              {/* <td>{user.time}</td> */}

            </tr>
          ))}
        </tbody>
      </table>
      <UserModal user={selectedUser} onClose={closeModal} /> {/* Render the modal */}
    </div>
  );
};

const UserModal = ({ user, onClose }) => {
  if (!user) return null; // If there's no user, don't render the modal

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>User Details</h2>
        <p><strong>Name:</strong> {user.name}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Mobile Number:</strong> {user.mobilenumber}</p>
        <p><strong>Total Amount:</strong> {user.amount}</p>
        <p><strong>No. of Campaigns:</strong> {user.campaigndetails.length}</p>
        {/* Add more fields as necessary */}
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default GeneralUsersList;
