import React, { useContext, useEffect, useState } from 'react';
import { CampaignContext } from '../../../../../Context/CampaignContext';
import './Campaigns.css';
import axiosInstance from '../../../../../Utils/axiosInstance';

const UserCampaigns1 = () => {
  const {
    userCampaigns,
    loading,
    newCampaign,
    setImageUrl,
    imageUrl,
    handleChange,
    openModal,
    isModalOpen,
    closeModal,
    setUserCampaigns,
    setLoading,
    uploadImageToContext, // Function to upload image in context
  } = useContext(CampaignContext);

  const [isImagePopupOpen, setIsImagePopupOpen] = useState(false);
  const hash = localStorage.getItem("hash");
  const [base64, setbase64] = useState("");

  const handleAction = async (email_hash, campId) => {
    try {
      const response = await axiosInstance.post('/user/fetchimage', { email_hash, campId });
      const images = response.data.data.map(image =>
        `data:${image.contentType};base64,${image.data}`
      );
      setImageUrl(images);
      setIsImagePopupOpen(true);
    } catch (error) {
      console.error("Error fetching images:", error);
      alert("Failed to fetch images: " + error.message);
    }
  };

  const uploadImage = (e) => {
    const file = e.target.files[0];
    if (!file) {
        alert('No file selected');
        return;
    }

    const reader = new FileReader();

    reader.onloadend = () => {
        const base64Image = reader.result.split(',')[1]; // Get the Base64 string without the prefix
        setbase64(base64Image);
    };

    reader.readAsDataURL(file); // Read the file as a data URL
};



  useEffect(() => {
    const fetchCampaigns = async () => {
      setLoading(true);
      try {
        const response = await axiosInstance.post("/user/usercampaigndetails", { hash });
        const allCampaigns = response.data.data.map(item => ({
          campaign_id: item.campaign_id,
          campaign_title: item.campaign_title,
          campaign_type: item.campaign_type,
          budget: item.budget,
          status: item.status,
          campaign_address: item.campaign_address,
          start_date: item.start_date,
          end_date: item.end_date,
        }));
        setUserCampaigns(allCampaigns);
      } catch (error) {
        console.error('Error fetching campaign data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, [setLoading, setUserCampaigns]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem('hash');

    if (!emailHash) {
      alert("Email hash not found in local storage.");
      return;
    }

    const campaignData = {
      hash: emailHash,
      info: newCampaign,
      base64: base64
    };

    try {
      await axiosInstance.post('/user/campaigndata', campaignData);
      console.log(campaignData);
      setUserCampaigns(prev => [...prev, campaignData.info]);
    } catch (error) {
      console.error('Error creating campaign:', error);
      alert("Failed to create campaign: " + error.response?.data.message || error.message);
    } finally {
      closeModal();
    }
  };

  const closeImagePopup = () => {
    setIsImagePopupOpen(false);
    setImageUrl('');
  };

  return (
    <div>
      <h1>Campaigns</h1>
      <button onClick={openModal}>Create Campaign</button>

      {isImagePopupOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={closeImagePopup}>&times;</span>
            {imageUrl && <img src={imageUrl} alt="Campaign" />}
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2>Create New Campaign</h2>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="campaign_title"
                value={newCampaign.campaign_title}
                onChange={handleChange}
                placeholder="Campaign Title"
                required
              />
              <input
                type="text"
                name="campaign_type"
                value={newCampaign.campaign_type}
                onChange={handleChange}
                placeholder="Campaign Type"
                required
              />
              <textarea
                name="campaign_description"
                value={newCampaign.campaign_description}
                onChange={handleChange}
                placeholder="Campaign Description"
                required
              />
              <input
                type="file"
                name="banner"
                onChange={uploadImage}
                required
              />
              <input
                type="text"
                name="campaign_address"
                value={newCampaign.campaign_address}
                onChange={handleChange}
                placeholder="Location"
                required
              />
              <input
                type="number"
                name="budget"
                value={newCampaign.budget}
                onChange={handleChange}
                placeholder="Estimated Budget"
                required
              />
              <input
                type="date"
                name="start_date"
                value={newCampaign.start_date}
                onChange={handleChange}
                required
              />
              <input
                type="date"
                name="end_date"
                value={newCampaign.end_date}
                onChange={handleChange}
                required
              />
              <button type="submit">Create Campaign</button>
              <button type="button" onClick={closeModal}>Cancel</button>
            </form>
          </div>
        </div>
      )}

      <section>
        <h2>User Campaign Overview</h2>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Campaign Name</th>
                <th>Type</th>
                <th>Est Budget</th>
                <th>Timeline</th>
                <th>Location</th>
                <th>Status</th>
                {/* <th>Banner</th> */}
              </tr>
            </thead>
            <tbody>
              {userCampaigns.length > 0 ? (
                userCampaigns.map((campaign) => (
                  <tr key={campaign.campaign_id}>
                    <td>{campaign.campaign_title || 'N/A'}</td>
                    <td>{campaign.campaign_type || 'N/A'}</td>
                    <td>{campaign.budget || 'N/A'}</td>
                    <td>{`${new Date(campaign.start_date).toLocaleDateString()} - ${new Date(campaign.end_date).toLocaleDateString()}`}</td>
                    <td>{campaign.campaign_address || 'N/A'}</td>
                    <td>{campaign.status}</td>
                    <td>
                      {/* <button onClick={() => handleAction(hash, campaign.campaign_id)}>View</button> */}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7">No campaigns found.</td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
};

export default UserCampaigns1;
