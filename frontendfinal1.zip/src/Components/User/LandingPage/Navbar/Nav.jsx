import React from 'react'
import './Navbar.css';
import { Link } from 'react-router-dom';

const Nav = () => {


    return (
        <div>
            <nav className="navbar">
                <div className="logo">
                    <h1>NGO Name</h1>
                </div>
                <ul className="nav-links">
                    <li><a href="#about">Home</a></li>
                    {/* <li><a href="#about">About Us</a></li> */}
                    {/* <li><a href="#projects">What We Do</a></li> */}
                    {/* <li><a href="#get-involved">Get Involved</a></li> */}
                    {/* <li><a href="#contact">Contact</a></li> */}
                </ul>
                <div className="auth-links">
                    <Link to="/profile" className="signin">Account</Link>
                    {/* <Link to="/signup" className='signup'>Sign Up</Link> */}
                </div>
            </nav>

        </div>
    )
}

export default Nav
