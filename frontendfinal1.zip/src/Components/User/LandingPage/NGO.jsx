import React from 'react'

const NGO = () => {

  return (
    <div>
        
    </div>
  )
}

export default NGO
