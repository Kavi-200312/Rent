import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import CampaignDetails from '../CampaignDetails/CampaignDetails';
import './RegisteredUserList.css';

const RegisteredUserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCampaigns, setSelectedCampaigns] = useState([]);
  const [showDetails, setShowDetails] = useState(false);
  const [viewingCampaignDetails, setViewingCampaignDetails] = useState(false);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get('/admin/allusers');
        console.log(response);

        setUsers(response.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleAction = async (hash) => {
    try {
      const response = await axiosInstance.post('/admin/campaigndataperuser', { hash });
      const campaignsData = response.data.data;

      // Flatten the campaigns from the response
      const campaigns = campaignsData.flatMap(user => user.campaigndetails);

      if (campaigns && campaigns.length > 0) {
        setSelectedCampaigns(campaigns);
        setShowDetails(true);
        setViewingCampaignDetails(true); // Set to true when viewing campaign details
      } else {
        alert("No campaigns found for this user.");
      }
    } catch (err) {
      console.error("Error fetching campaigns:", err);
      alert("Failed to fetch campaigns: " + err.message);
    }
  };

  const closeDetails = () => {
    setShowDetails(false);
    setSelectedCampaigns([]);
    setViewingCampaignDetails(false); // Reset viewing state
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      {viewingCampaignDetails ? (
        <CampaignDetails
          campaigns={selectedCampaigns}
          onClose={closeDetails}
        />
      ) : (
        <div>
          <h2>Registered User List</h2>
          <table>
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>Mobile Number</th>
                <th>No. of Campaigns</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user._id}>
                  <td>{user.fullname}</td>
                  <td>{user.email}</td>
                  <td>{user.mobile_number}</td>
                  <td>{user.campaigndetails ? user.campaigndetails.length : 0}</td>
                  <td>{user.status}</td>
                  <td>
                    <button onClick={() => handleAction(user.email_hash)}>View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RegisteredUserList;
