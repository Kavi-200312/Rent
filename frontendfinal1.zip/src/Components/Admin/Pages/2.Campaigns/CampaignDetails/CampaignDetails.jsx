import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom'; 
import axiosInstance from '../../../../../../Utils/axiosInstance';
import './CampaignDetails.css'; 

const CampaignDetails = () => {
  const [userDetails, setUserDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const location = useLocation();

  const getQueryParams = () => {
    const params = new URLSearchParams(location.search);
    return {
      emailHash: params.get('hash'),
    };
  };

  useEffect(() => {
    const fetchUserDetails = async () => {
      const { emailHash } = getQueryParams();

      if (emailHash) {
        try {
          const response = await axiosInstance.get(`/admin/finduserbyhash?hash=${emailHash}`);
          setUserDetails(response.data.data);
        } catch (err) {
          setError(err);
        } finally {
          setLoading(false);
        }
      } else {
        setError(new Error("Email hash is missing."));
        setLoading(false);
      }
    };

    fetchUserDetails();
  }, [location.search]);

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (error) {
    return <div className="error">Error fetching user details: {error.message}</div>;
  }

  return (
    <div className="user-details-container">
      <h2>User Details</h2>
      {userDetails ? (
        <div className="user-details">
          <img src={userDetails.profileImage || 'placeholder-image-url.jpg'} alt={`${userDetails.fullname}'s profile`} className="user-profile-image" />
          <p><strong>Full Name:</strong> {userDetails.fullname}</p>
          <p><strong>Email:</strong> {userDetails.email}</p>
          <p><strong>Status:</strong> {userDetails.status}</p>
          <p><strong>Mobile Number:</strong> {userDetails.mobile_number}</p>
          <p><strong>Account Created:</strong> {new Date(userDetails.account_created_date).toLocaleDateString()}</p>
          <h3>Campaigns</h3>
          {userDetails.campaigndetails.length > 0 ? (
            <ul className="campaign-list">
              {userDetails.campaigndetails.map((campaign) => (
                <li key={campaign._id} className="campaign-item">
                  <strong>{campaign.campaign_title}</strong>: {campaign.campaign_description} (Status: {campaign.status})
                </li>
              ))}
            </ul>
          ) : (
            <p>No campaigns found.</p>
          )}
        </div>
      ) : (
        <p>No user details available.</p>
      )}
    </div>
  );
};

export default CampaignDetails;
