import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, ResponsiveContainer
} from 'recharts';

const Dashboard = () => {
  const [incomeExpenseData, setIncomeExpenseData] = useState([]);
  const [campaignCount, setCampaignCount] = useState(0);
  const [totalCollection, setTotalCollection] = useState(0);
  const [totalExpense, setTotalExpense] = useState(0);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const incomeExpenseResponse = await axiosInstance.get('/income-expense');
        const campaignCountResponse = await axiosInstance.get('/campaign-count');
        const collectionResponse = await axiosInstance.get('/total-collection');
        const expenseResponse = await axiosInstance.get('/total-expense');
        const usersResponse = await axiosInstance.get('/users');

        setIncomeExpenseData(incomeExpenseResponse.data);
        setCampaignCount(campaignCountResponse.data.total);
        setTotalCollection(collectionResponse.data.total);
        setTotalExpense(expenseResponse.data.total);
        setUsers(usersResponse.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchDashboardData();
  }, []);

  const pieData = [
    { name: 'Total Collection', value: totalCollection },
    { name: 'Total Expense', value: totalExpense },
  ];

  return (
    <div>
      <h1>Dashboard</h1>

      <h2>Total Income & Expense</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={incomeExpenseData}>
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="income" stroke="#82ca9d" />
          <Line type="monotone" dataKey="expense" stroke="#ff7300" />
        </LineChart>
      </ResponsiveContainer>

      <h2>Campaign Count: {campaignCount}</h2>

      <h2>Total Collection & Total Expense</h2>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie data={pieData} innerRadius={60} outerRadius={80} fill="#8884d8" dataKey="value">
            {pieData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={index === 0 ? '#0088FE' : '#FF8042'} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>

      <h2>Registered Users</h2>
      <ul>
        {users.map(user => (
          <li key={user.id}>
            {user.name} - {user.email}
            <ul>
              <li>Profile: {user.profile}</li>
              <li>Campaigns: {user.campaigns.join(', ')}</li>
              <li>History: {user.history.join(', ')}</li>
              <li>Bills: {user.bills.join(', ')}</li>
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
