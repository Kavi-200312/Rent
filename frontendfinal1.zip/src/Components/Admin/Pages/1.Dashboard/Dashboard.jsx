import React from 'react'
import './Dashboard.css'
import { LineChart } from './CHARTS/LineChart/LineCharts'
import { PieChart } from './CHARTS/PieCharts/PieCharts'

const CampaignDashboard = () => {
  return (

    <div className='linechart'>
        <div><LineChart/></div>
        <div className='piechart'><PieChart/></div>
    </div>

  )
}

export default CampaignDashboard
