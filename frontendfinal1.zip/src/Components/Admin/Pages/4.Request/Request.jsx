import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';

const Request = () => {
  const [users, setUsers] = useState([]);
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsersAndBills = async () => {
      try {
        const [userResponse, billResponse] = await Promise.all([
          axiosInstance.get('/admin/verifyuserdetails'),
          axiosInstance.get('/admin/getbills')
        ]);
        setUsers(userResponse.data.data);
        setBills(billResponse.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUsersAndBills();
  }, []);

  const updateUserStatus = async (userId, currentStatus) => {
    try {
      const response = await axiosInstance.put(`/admin/rejectuser`, {
        userId,
        documentVerified: !currentStatus,
      });
      setUsers(users.map(user => (user.id === userId ? { ...user, documentVerified: response.data.documentVerified } : user)));
    } catch (err) {
      setError(err.message);
    }
  };

  const rejectUser = async (userId) => {
    try {
      await axiosInstance.post(`/admin/rejectuser`, { userId });
      setUsers(users.filter(user => user.id !== userId));
    } catch (err) {
      setError(err.message);
    }
  };

  const rejectBill = async (billId) => {
    try {
      await axiosInstance.put(`/admin/rejectbills`, { billId });
      setBills(bills.filter(bill => bill.bill_id !== billId));
    } catch (err) {
      setError(err.message);
    }
  };

  const verifyBill = async (billId) => {
    try {
      const response = await axiosInstance.put(`/admin/verifybills`, { billId });
      setBills(bills.map(bill => (bill.bill_id === billId ? { ...bill, status: response.data.status } : bill)));
    } catch (err) {
      setError(err.message);
    }
  };

  const viewUser = (userId) => {
    // Implement your view user logic here (e.g., navigate to a user detail page)
    console.log(`Viewing user with ID: ${userId}`);
  };

  const viewBill = (billId) => {
    // Implement your view bill logic here (e.g., navigate to a bill detail page)
    console.log(`Viewing bill with ID: ${billId}`);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2>Users</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Document Verified</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td>{user.fullname}</td>
              <td>{user.email}</td>
              <td>{user.documentVerified ? 'Yes' : 'No'}</td>
              <td>
                <button onClick={() => updateUserStatus(user.id, user.documentVerified)}>
                  {user.documentVerified ? 'Revoke' : 'Verify'}
                </button>
                <button onClick={() => rejectUser(user.id)}>Reject</button>
                <button onClick={() => viewUser(user.id)}>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Bills</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Bill ID</th>
            <th>Description</th>
            <th>Status</th>
            <th>Uploaded At</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {bills.map(bill => (
            <tr key={bill.bill_id}>
              <td>{bill.bill_id}</td>
              <td>{bill.files}</td>
              <td>{bill.status}</td>
              <td>{new Date(bill.uploadedAt).toLocaleString()}</td>
              <td>
                <button onClick={() => verifyBill(bill.bill_id)}>Verify</button> {/* New Verify button */}
                <button onClick={() => rejectBill(bill.bill_id)}>Reject Bill</button>
                <button onClick={() => viewBill(bill.bill_id)}>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Request;
