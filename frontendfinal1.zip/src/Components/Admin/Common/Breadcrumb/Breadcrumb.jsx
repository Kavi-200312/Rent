import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Breadcrumb.css'; // Ensure you import the CSS

const Breadcrumb = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/admin').filter(Boolean); // Filter out empty segments

  return (
    <nav aria-label="Breadcrumb">
      <ol className="breadcrumb">
        <li>
          <Link to="/admin">DASHBOARD</Link>
        </li>
        {pathnames.map((pathname, index) => {
          const routeTo = `/${pathnames.slice(0, index + 1).join('/')}`;
          return (
            <li key={index}>
              <Link to={routeTo} aria-current={index === pathnames.length - 1 ? "page" : undefined}>
                {pathname.replace('-', ' ').toUpperCase()}
              </Link>
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

export default Breadcrumb;
