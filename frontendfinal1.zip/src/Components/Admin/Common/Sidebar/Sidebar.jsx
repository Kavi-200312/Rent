import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';
import { FaTachometerAlt,FaFlag, FaUsers, FaEnvelope, FaClipboardList} from 'react-icons/fa'; // Add icons from react-icons

const Sidebar = () => {
  const [isManagementOpen, setManagementOpen] = useState(false);

  const toggleManagementMenu = () => {
    setManagementOpen(!isManagementOpen);
  };

  return (
    <div className="sidebar">
      <h2>NGO Admin Panel</h2>
      <ul>
        <li><Link to="/admin"><FaTachometerAlt /> Dashboard</Link></li>
        <li><Link to="/admin/campaigns"><FaFlag /> Campaign </Link></li>

        <li>
          <button onClick={toggleManagementMenu} className="submenu-toggle">
            <FaUsers /> User Management
          </button>
          {isManagementOpen && (
            <ul className="submenu">
              <li><Link to="/admin/registered-users">Registered Users</Link></li>
              <li><Link to="/admin/general-users">General Users</Link></li>
            </ul>
          )}
        </li>
        <li><Link to="/admin/requests"><FaClipboardList /> Requests</Link></li>
        <li><Link to="/admin/queries"><FaEnvelope /> Queries</Link></li>
        <li><Link to="/logout">Logout</Link></li>
      </ul>
    </div>
  );
}

export default Sidebar;
