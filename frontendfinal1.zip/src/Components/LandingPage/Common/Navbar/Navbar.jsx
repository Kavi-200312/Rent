// import React from 'react'
// import './Navbar.css';
// import { Link } from 'react-router-dom';

// const Navbar = () => {
//     return (
//         <div>
//             <nav className="navbar">
//                 <div className="logo">
//                     <h1>NGO Name</h1>
//                 </div>
//                 <ul className="nav-links">
//                     <li><Link to="/">Home</Link></li>
//                     <li><Link to="/about">About Us</Link></li>
//                     <li><Link to="/whatwedo">What We Do</Link></li>
//                     <li><Link to="/get-involved">Get Involved</Link></li>
//                     <li><Link to="/contact">Contact</Link></li> 
//                 </ul>
//                 <div className="auth-links">
//                     <Link to="/signin" className="signin">Sign In</Link>
//                     {/* <Link to="/signup" className='signup'>Sign Up</Link> */}
//                 </div>
//             </nav>
//         </div>
//     )
// }
// export default Navba
import React, { useState } from 'react';
import './Navbar.css';
import { Link } from 'react-router-dom';

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleNavbar = () => {
        setIsOpen(!isOpen);
    };

    return (
        <div>
            <nav className="navbar">
                <div className="logo">
                    <h1>NGO Name</h1>
                </div>
                <div className={`nav-links ${isOpen ? 'open' : ''}`}>
                    <ul>
                        <li><Link to="/">Home</Link></li>
                       
                    </ul>
                    {/* <div className="auth-links"> */}
                        <Link to="/signin" className="signin">Sign In</Link>
                    {/* </div> */}
                </div>
                <div className="hamburger" onClick={toggleNavbar}>
                    <div className={`line ${isOpen ? 'active' : ''}`}></div>
                    <div className={`line ${isOpen ? 'active' : ''}`}></div>
                    <div className={`line ${isOpen ? 'active' : ''}`}></div>
                </div>
            </nav>
        </div>
    );
}

export default Navbar;

