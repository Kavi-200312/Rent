import React from 'react';
import './Donate.css'

export const TransactionPage = () => {

  return (
    <div>
      <form className='forms'>
        <label>Name:
          <input type="text"
            placeholder='Enter your Name' />
        </label>
        <br />
        <label>Email:
          <input type="email"
            placeholder='Enter email'
            required />
        </label>
        <br />
        <label>Phone Number:
          <input type="text"
            placeholder='Enter Phone number'
            required />
        </label>
        <br />
        <label>Amount:
          <input type="text"
            placeholder='Enter Amount'
            required />
        </label>
        <div className='button_for_donate'>
          <button>Pay</button>
        </div>
      </form>
    </div>

  );
};

