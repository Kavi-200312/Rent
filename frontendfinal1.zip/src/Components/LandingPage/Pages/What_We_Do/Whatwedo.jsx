export const WhatWeDo = () => {
    return (
        <div>
            What we do
        </div>
    )
}