export const Getinvolved = () => {

    return (
        <>
            <h1>
                Get Involved
            </h1>
        </>
    )
}