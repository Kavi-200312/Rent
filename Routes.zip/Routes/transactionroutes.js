const express = require("express");
const { saveTransaction, getAllTransactionDetails, pushCampaignDetailsIntoTransactionForm, getTransactionResponse, getTransResponse } = require("../Controller/transactioncontroller");
const transactionRouter = express.Router();


transactionRouter.post("/save", saveTransaction);
transactionRouter.get("/all", getAllTransactionDetails);
transactionRouter.post("/campaigndata", pushCampaignDetailsIntoTransactionForm);
transactionRouter.post("/trans",getTransactionResponse)

transactionRouter.post("/getresponse",getTransResponse)


module.exports = { transactionRouter }