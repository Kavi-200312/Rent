const express = require("express");
const { userLogin, userData, registerUser, getUsersCount, insertCampaignDataByEmailHash, userLogout, getCampaignCountByMonth, getCampaignCountByYear, getLiveCampaings, getCancelledCampaings, getUpcomingCampaings, getApprovedCampaings, getNotApprovedCampaings, getLiveWithDetails, getCompleteCampaignWithDetails, getLiveCampaignWithDetails, getAllCampaignDetails, getCampaignDetailsPerUserByEmailHash, getUserCampaignImages } = require("../Controller/usercontroller");
const { verifyToken } = require("../Middlewares/auth");
const { saveTransaction, getAllTransactionDetails } = require("../Controller/transactioncontroller");
const { insertBillDetailsIntoCampaign, uploadImage, fetchImage } = require("../Controller/admincontroller");
const userRouter = express.Router();

userRouter.post("/register", registerUser);
userRouter.post("/login", userLogin)
userRouter.get('/data', verifyToken, userData)
userRouter.get("/count", verifyToken, getUsersCount);
userRouter.post("/logout", verifyToken, userLogout);
userRouter.get("/monthcount", getCampaignCountByMonth)
userRouter.get("/yearcount", getCampaignCountByYear)
userRouter.get("/live", getLiveCampaings)
userRouter.get("/cancel", getCancelledCampaings)
userRouter.get("/upcoming", getUpcomingCampaings)
userRouter.get("/approve", getApprovedCampaings)
userRouter.get("/notapprove", getNotApprovedCampaings)
userRouter.get("/livedetails", getLiveCampaignWithDetails)
userRouter.get("/completecampaigndetails", getCompleteCampaignWithDetails)

userRouter.post("/getbannerpercampaign", getUserCampaignImages);


//campaign
userRouter.post("/usercampaigndetails", getCampaignDetailsPerUserByEmailHash);
userRouter.post('/campaigndata', insertCampaignDataByEmailHash);


//transaction
userRouter.post("/savetr", saveTransaction);
userRouter.get("/gettr", getAllTransactionDetails);




userRouter.post("/savebills", insertBillDetailsIntoCampaign);


userRouter.post("/image", uploadImage);
userRouter.post("/fetchimage", fetchImage);


module.exports = userRouter;