const { default: axios } = require("axios");
const { Transaction } = require("../Model/transaction");

const saveTransaction = async (req, res) => {
    // console.log(req.body);

    const { name, email, amount, mobilenumber, user_hash, campaignname } = req.body;
    try {
        // const user = await Transaction.findOne({mobilenumber:mobilenumber})
        // if(!user){
        if (!campaignname) {

            const transaction = await Transaction.create({ name: name, email: email, campaign_name: campaignname, amount: amount, mobilenumber: mobilenumber });
            transaction.save();
        }
        const transaction = await Transaction.create({ name: name, email: email, amount: amount, mobilenumber: mobilenumber });
        transaction.save();
        // }
        return res.status(200).json({ code: 200, message: "Transaction saved" })

    } catch (error) {
        return res.status(200).json({ code: 400, errorMessage: error.message })
    }
}
const getTransactionDocumentCount = async (req, res) => {
    const totalTransactionDocuments = await Transaction.countDocuments();
    if (totalTransactionDocuments === 0) {

        return res.status(200).json({ code: 400, message: "No transactions found" })
    }
    return res.status(200).json({ code: 200, data: totalTransactionDocuments });
}

const getAllTransactionDetails = async (req, res) => {

    const totalTransactionDocuments = await Transaction.countDocuments();
    if (totalTransactionDocuments === 0) {
        return res.status(200).json({ code: 400, message: "No transactions found" })
    }
    const transactionDocuments = await Transaction.find({});
    return res.status(200).json({ code: 200, data: transactionDocuments });
}

const pushCampaignDetailsIntoTransactionForm = async (req, res) => {
    const { email, info } = req.body;
    // console.log(req.body);
    try {

        const result = await Transaction.updateOne({ email: email }, { $push: { campaignDetails: info } }, { new: true })
        // console.log(result);
        if (result.modifiedCount > 0) {
            return res.status(200).json({ code: 200, message: "Object added into array successfully" })
        }
        else {
            return res.status(200).json({ code: 400, message: "Unsuccessfull" })
        }
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}


const getTransactionResponse = async (req, res) => {
    // const { merchantName, platform, billerName, category, merchantNumber, last4Digits, mobileNumber } = req.body;

    console.log('Payment Request Received:', req.body);
    const customerParams = { "Last 4 digits of Credit Card Number": req.body.creditcardnumber, "Registered Mobile Number": req.body.registeredmobilenumber }

    const obj = {
        "MerchantName": req.body.name,
        "Platform": req.body.platform,
        "amount": req.body.amount,
        "billerName": process.env.biller_name,
        "category": process.env.category,
        "MerchantNumber": req.body.mobilenumber,
        customerParams
    }
    console.log(obj, "Line 79");

    await axios.post(`http://192.168.1.28:6012/api/pg/billfetch`, obj)
        .then((response) => {
            console.log(response, 'LIne kjsdfksflksdflksjflksajflksjflksjflksjfsalkjfsalkjfsalkj')
            console.log(response.data.code, "line 8555555555555555555555555");
            console.log(response.data, "Liuerfijsdfjsdlfjdlskjfksdjfsjfslkfjslk");
            if (response.data.code === 200) {
                return res.status(200).json({ code: 200, value: response.data.value })
            } else {
                return res.status(200).json({ code: 400, msg: "Try Again" })
            }
        })
}


const getTransResponse = async (req, res) => {
    try {
        console.log(req.body);
        const transaction = await Transaction.create(req.body);
        transaction.save();


        return res.status(200).json({ code: 200 })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}


module.exports = { saveTransaction, getTransResponse, getTransactionResponse, getAllTransactionDetails, pushCampaignDetailsIntoTransactionForm };