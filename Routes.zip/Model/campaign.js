const mongoose = require("mongoose");
const { v4: uuidv4 } = require('uuid');

const campaignSchema = new mongoose.Schema({
    campaign_id: { type: String, default: uuidv4, unique: true },
    campaign_title: { type: String, required: true },
    campaign_type: { type: String },
    campaign_description: { type: String },
    start_date: { type: Date },
    end_date: { type: Date },
    campaign_address: { type: String },
    budget: { type: String, default: "0" },
    // banner: {
    //     data: Buffer,

    //     contentType: { type: String }
    // },
    images: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Image' }],
    bills: [
        {
            bill_id: { type: String, default: uuidv4, unique: true },
            files: { type: String, required: true },
            claiming_amount: { type: String },
            status: {
                type: String,
                enum: ['PENDING', 'APPROVED', 'VERIFIED'],
                default: 'PENDING'
            },
            uploadedAt: { type: Date, default: Date.now }
        }
    ],
    status: { type: String, enum: ['LIVE', 'COMPLETED', 'CANCELLED', 'UPCOMING', "NOT_APPROVED", "APPROVED"], default: 'NOT_APPROVED' },
    reason_for_cancellation: { type: String, default: "NA" }

});


// const Campaign = mongoose.model("campaign", campaignSchema);

module.exports = { campaignSchema }