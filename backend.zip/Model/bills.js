const mongoose = require("mongoose");

const billSchema = new mongoose.Schema({

    bills: { type: String, required: true },
    claiming_amount: { type: String },
    status: {
        type: String,
        enum: ['PENDING', 'APPROVED', 'VERIFIED'],
        default: 'PENDING'
    },
    uploadedAt: { type: Date, default: Date.now }
})


const BillModel = mongoose.model("bills", billSchema);

module.exports = { BillModel };