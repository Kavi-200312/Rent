const mongoose = require("mongoose");

const campaignSchema = new mongoose.Schema({
    campaign_title: { type: String, required: true },
    campaign_type: { type: String },
    campaign_description: { type: String },
    start_date: { type: Date },
    end_date: { type: Date },
    banner: { type: String },
    campaign_address: { type: String },
    estimated_budget: { type: String, default: "NA" },
    collected_amount: { type: String },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },

    status: { type: String, enum: ['LIVE', 'COMPLETED', 'CANCELLED', 'UPCOMING', "NOT_APPROVED", "APPROVED"], default: 'NOT_APPROVED' },
    reason_for_cancellation: { type: String, default: "NA" }

});


const Campaign = mongoose.model("campaign", campaignSchema);

module.exports = { Campaign }