const mongoose = require("mongoose");

const fundModel = new mongoose.Schema({
    campaignName: {
        type: String,
    },
    Description: {
        type: String
    },
    amount: {
        type: String,
    },
    emailHash: {
        type: String
    }

}, {
    timestamps: true
})



const fundRequestModel = mongoose.model("fundRequest", fundModel);

module.exports = { fundRequestModel }