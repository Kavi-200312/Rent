const mongoose = require("mongoose");

const querySchema = new mongoose.Schema({
    name: { type: String },
    email: { type: String },
    mobile_number: { type: String },
    message: { type: String },

})

const Query = mongoose.model("query", querySchema);

module.exports = { Query }