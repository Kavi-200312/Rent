const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String
    },
    amount: {
        type: String,
    },
    mobilenumber: {
        type: String,
    },

    transactionid: {
        type: String
    },
    hash: { type: String },
    campaign_id: { type: String },
    campaigndetails: [Object],
    pg_response: [Object],

}, {
    timestamps: true
})



const Transaction = mongoose.model("transaction", transactionSchema);

module.exports = { Transaction }