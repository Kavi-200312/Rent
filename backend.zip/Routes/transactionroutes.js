const express = require("express");
const { saveTransaction, getAllTransactionDetails, pushCampaignDetailsIntoTransactionForm, getTransactionResponse, getTransResponse, getTransactionByCampaignId } = require("../Controller/transactioncontroller");
const transactionRouter = express.Router();


transactionRouter.post("/save", saveTransaction);
transactionRouter.get("/all", getAllTransactionDetails);
transactionRouter.post("/campaigndata", pushCampaignDetailsIntoTransactionForm);
transactionRouter.post("/transactionpercampaign", getTransactionByCampaignId)
transactionRouter.post("/trans", getTransactionResponse)


transactionRouter.post("/getresponse", getTransResponse)


module.exports = { transactionRouter }