import React, { useState } from 'react';
import './Navbar.css';
import { Link } from 'react-router-dom';

const Navbar = () => {
    return (
        <div>
            <nav className="navbar">
                <div className="logo">
                    <div className='ngo'><li><Link to="/">NGO</Link></li></div>
                </div>
                <div className='nav-links'>
                    <div><li><Link to="/signin" className="signin">Sign In</Link></li></div>
                </div>
            </nav>
        </div>
    );
}

export default Navbar;

