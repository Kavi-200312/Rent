import React, { useState } from 'react';
import axios from 'axios';
import './Footer.css';

const Footer = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('http://localhost:5000/api/general/savequeries', {
                name,
                email,
                message,
            });
            // console.log('Response:', response.data);
            setName('');
            setEmail('');
            setMessage('');
        } catch (error) {
            console.error('Error submitting feedback:', error);
        }
    };

    return (
        <footer>
            <div className='footer_flex'>
                <div className='ngo_content'>
                    <h1>About</h1>
                </div>
                <div className='landingpage_contect_page'>
                    <p>Feedback</p>
                    <form className='footer_forms' onSubmit={handleSubmit}>
                        <label className='footer_name_feedbackname'>
                            Name:
                            <input
                                type="text"
                                placeholder='Enter name'
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                            />
                        </label>
                        <br />
                        <label className='footer_email_form'>Email:
                            <input
                                type="email"
                                placeholder='Enter email'
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />
                        </label>
                        <br />
                        <label>
                            Message:
                            <textarea
                                className='text_area'
                                placeholder='Write your inquiries..'
                                value={message}
                                onChange={(e) => setMessage(e.target.value)}
                            />
                        </label>
                        <div className='content_button'>
                            <button type="submit" className='cont_colors'>Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
