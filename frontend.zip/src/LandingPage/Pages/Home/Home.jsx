import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';
import Footer from '../../Common/Footer/Footer';
import axiosInstance from '../../../Utils/axiosInstance';

export const HomePage = () => {
  const navigate = useNavigate();
  const [campaigns, setCampaign] = useState([]);

  const handleDonate = (campaign) => {
    navigate('/transaction', { state: { campaign, date: new Date().toLocaleString() } });
  };

  const fetchCampaigns = async () => {
    try {
      const res = await axiosInstance.get('/general/getallca');
      if (res.data.code === 200) {
        setCampaign(res.data.data.map(item => item.campaigndetails).flat());
      }
    } catch (error) {
      console.error("Error fetching campaigns:", error);
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, []);

  return (
    <div>
      <div className='container'>
        <div className='donate_1stcolumn'>
          {campaigns.map((campaign, index) => (
            <div className='campaign' key={index}>
              <h3>{campaign.campaign_title}</h3>
              <p>{campaign.campaign_description}</p>
              {/* <p><strong>Type:</strong> {campaign.campaign_type}</p> */}
              <p><strong>Address:</strong> {campaign.campaign_address}</p>
              {/* <p><strong>Budget:</strong> {campaign.budget}</p> */}
              <p><strong>Status:</strong> {campaign.status}</p>
             
                <button onClick={() => handleDonate(campaign)}>Donate</button>
            </div>
          ))}
        </div>
      </div>

      <footer>
        <Footer />
      </footer>
    </div>
  );
};
