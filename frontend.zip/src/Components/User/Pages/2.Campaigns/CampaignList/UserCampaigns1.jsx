import React, { useContext, useEffect, useState } from 'react';
import { CampaignContext } from '../../../../../Context/CampaignContext';
import './Campaigns.css';
import axiosInstance from '../../../../../Utils/axiosInstance';

const UserCampaigns1 = () => {
  const {
    userCampaigns,
    loading,
    newCampaign,
    setImageUrl,
    imageUrl,
    handleChange,
    openModal,
    isModalOpen,
    closeModal,
    setUserCampaigns,
    setLoading,
  } = useContext(CampaignContext);

  const [isImagePopupOpen, setIsImagePopupOpen] = useState(false);
  const [isRequestFundsPopupOpen, setIsRequestFundsPopupOpen] = useState(false);
  const hash = localStorage.getItem("hash");
  const [base64, setBase64] = useState("");
  const [fundRequest, setFundRequest] = useState({
    campaignName: '',
    description: '',
    amount: '',
    emailHash: hash
  });

  const handleAction = async (email_hash, campId) => {
    try {
      const response = await axiosInstance.post('/user/fetchimage', { email_hash, campId });
      const images = response.data.data.map(image =>
        `data:${image.contentType};base64,${image.data}`
      );
      setImageUrl(images);
      setIsImagePopupOpen(true);
    } catch (error) {
      console.error("Error fetching images:", error);
      alert("Failed to fetch images: " + error.message);
    }
  };

  const fetchCampaigns = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/user/usercampaigndetails", { hash });
      const allCampaigns = response.data.data.map(item => ({
        campaign_id: item.campaign_id,
        campaign_title: item.campaign_title,
        campaign_type: item.campaign_type,
        budget: item.budget,
        status: item.status,
        campaign_address: item.campaign_address,
        start_date: item.start_date,
        end_date: item.end_date,
      }));
      setUserCampaigns(allCampaigns);
    } catch (error) {
      console.error('Error fetching campaign data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, [setLoading, setUserCampaigns]);

  const handleRequestFundsChange = (e) => {
    const { name, value } = e.target;
    setFundRequest(prev => ({ ...prev, [name]: value }));
  };

  const handleRequestFundsSubmit = async (e) => {
    e.preventDefault();
    axiosInstance.post(`user/funds`, { fundRequest })
    setIsRequestFundsPopupOpen(false);
  };

  return (
    <div>
      <h1>Campaigns</h1>
      <button onClick={openModal}>Create Campaign</button>
      <button onClick={() => setIsRequestFundsPopupOpen(true)}>Request Funds</button>

      {isRequestFundsPopupOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setIsRequestFundsPopupOpen(false)}>&times;</span>
            <h2>Fund Request Form</h2>
            <form onSubmit={handleRequestFundsSubmit}>
              <label htmlFor="campaignName">Campaign Name:</label>
              <input
                type="text"
                id="campaignName"
                name="campaignName"
                value={fundRequest.campaignName}
                onChange={handleRequestFundsChange}
                required
              />

              <label htmlFor="description">Description:</label>
              <textarea
                id="description"
                name="description"
                value={fundRequest.description}
                onChange={handleRequestFundsChange}
                required
              />

              <label htmlFor="amount">Amount:</label>
              <input
                type="number"
                id="amount"
                name="amount"
                value={fundRequest.amount}
                onChange={handleRequestFundsChange}
                required
              />
              <button type="submit">Submit Request</button>
              <button type="button" onClick={() => setIsRequestFundsPopupOpen(false)}>Cancel</button>
            </form>
          </div>
        </div>
      )}

      {isImagePopupOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setIsImagePopupOpen(false)}>&times;</span>
            {imageUrl && <img src={imageUrl} alt="Campaign" />}
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2>Create New Campaign</h2>
            <form onSubmit={handleSubmit}>
              {/* Add your campaign creation form fields here */}
              <button type="submit">Create Campaign</button>
              <button type="button" onClick={closeModal}>Cancel</button>
            </form>
          </div>
        </div>
      )}

      <section>
        <h2>User Campaign Overview</h2>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Campaign Name</th>
                <th>Type</th>
                <th>Est Budget</th>
                <th>Timeline</th>
                <th>Location</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {userCampaigns.length > 0 ? (
                userCampaigns.map((campaign) => (
                  <tr key={campaign.campaign_id}>
                    <td>{campaign.campaign_title || 'N/A'}</td>
                    <td>{campaign.campaign_type || 'N/A'}</td>
                    <td>{campaign.budget || 'N/A'}</td>
                    <td>{`${new Date(campaign.start_date).toLocaleDateString()} - ${new Date(campaign.end_date).toLocaleDateString()}`}</td>
                    <td>{campaign.campaign_address || 'N/A'}</td>
                    <td>{campaign.status}</td>
                    <td>
                      {/* <button onClick={() => handleAction(hash, campaign.campaign_id)}>View</button> */}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7">No campaigns found.</td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
};

export default UserCampaigns1;
