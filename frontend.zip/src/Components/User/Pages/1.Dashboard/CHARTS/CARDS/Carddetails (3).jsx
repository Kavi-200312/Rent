import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Carddetails.css';

export const Carddetails = () => {
    const [totalUsers, setTotalUsers] = useState(0);
    const [dayCount, setDayCount] = useState(0);
    const [weekCount, setWeekCount] = useState(0);
    const [monthCount, setMonthCount] = useState(0);

    // useEffect(() => {
    //     const fetchData = async () => {
    //         try {
    //             const totalResponse = await axios.get('http://localhost:5000/api/user/total');
    //             const dayResponse = await axios.get('http://localhost:5000/api/user/daycount');
    //             const weekResponse = await axios.get('http://localhost:5000/api/user/weekcount');
    //             const monthResponse = await axios.get('http://localhost:5000/api/user/monthcount');

    //             setTotalUsers(totalResponse.data);
    //             setDayCount(dayResponse.data);
    //             setWeekCount(weekResponse.data);
    //             setMonthCount(monthResponse.data);
    //         } catch (error) {
    //             console.error('Error fetching data:', error);
    //         }
    //     };

    //     fetchData();
    // }, []);
    useEffect(() => {
        const fetchData = async () => {
            try {
                const totalResponse = await axios.get('http://localhost:5000/api/user/total');
                const dayResponse = await axios.get('http://localhost:5000/api/user/daycount');
                const weekResponse = await axios.get('http://localhost:5000/api/user/weekcount');
                const monthResponse = await axios.get('http://localhost:5000/api/user/monthcount');

                setTotalUsers(totalResponse.data.data || 0); 
                setDayCount(dayResponse.data.data.campaignCountday || 0);
                setWeekCount(weekResponse.data.data.campaignCountWeek || 0);
                setMonthCount(monthResponse.data.data.campaignCount || 0);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);
    
console.log(totalUsers,"/////////// total")
    return (
        <div className="card-details">
            <h2>User Statistics</h2>
            <div className="cards">
                <div className="card">
                    <h2>Total Campaigns</h2>
                    <p>{totalUsers}</p>
                </div>
                <div className="card">
                    <h2> Today's Campaigns</h2>
                    <p>{dayCount}</p>
                </div>
                {/* <div className="card">
                    <h2>Users This Week</h2>
                    <p>{weekCount}</p>
                </div> */}
                <div className="card">
                    <h2>Campaign This Month</h2>
                    <p>{monthCount}</p>
                </div>
            </div>
        </div>
    );
};
