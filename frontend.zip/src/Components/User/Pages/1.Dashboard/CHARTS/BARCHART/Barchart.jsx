import React, { useEffect, useState } from 'react';
import './Barchart.css';
import { Bar } from 'react-chartjs-2';
import axios from 'axios';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const BarChart = () => {
    const [chartData, setChartData] = useState({
        labels: ["Upcoming", "Ongoing", "Completed", "Cancellation"],
        datasets: [
            {
                label: 'Campaign Status',
                data: [],
                backgroundColor: [
                    'lightgreen',
                    'lightblue',
                    'lightgray',
                    'yellow'
                ]
            },
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Total Campaign History Data',
            },
        },
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [upcomingResponse, ongoingResponse, completedResponse, cancellationResponse] = await Promise.all([
                    axios.get('http://localhost:5000/api/user/upcoming'),
                    axios.get('http://localhost:5000/api/user/live'),
                    axios.get('http://localhost:5000/api/user/complete'),
                    axios.get('http://localhost:5000/api/user/cancel'),
                ]);

                console.log(upcomingResponse,"__--------------------");
                const salesData = [
                    upcomingResponse.data.data || 0,
                    ongoingResponse.data.data || 0,
                    completedResponse.data.data || 0,
                    cancellationResponse.data.data || 0,
                ];
                // console.log(salesData,"................... sales data.....................")
                setChartData(prevData => ({
                    ...prevData,
                    datasets: [{
                        ...prevData.datasets[0],
                        data: salesData,
                    }],
                }));
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "40vh", width: "800px" }} className='bar_chart'>
            <h2>Campaign Status</h2>
            <Bar data={chartData} options={options} />
        </div>
    );
};

export default BarChart;
