import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

const DoughnutChart = () => {
  const [totalContributions, setTotalContributions] = useState(0);
  const [totalExpenses, setTotalExpenses] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const contributionResponse = await axios.get('http://localhost:5000/api/user/contribution');
        const expenseResponse = await axios.get('http://localhost:5000/api/user/expense');
        setTotalContributions(contributionResponse.data.totalAmount);
        setTotalExpenses(expenseResponse.data.totalExpense);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const data = {
    labels: ['Total Contributions', 'Total Expenses'],
    datasets: [
      {
        data: [totalContributions, totalExpenses],
        backgroundColor: [
          'rgba(75, 192, 192, 1)',
          'rgba(255, 99, 132, 1)',
        ],
        hoverOffset: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Total Contributions vs Total Expenses',
      },
    },
  };

  return (
    <div>
      <h2>Total Contributions vs Expenses</h2>
      <Doughnut data={data} options={options} />
    </div>
  );
};

export default DoughnutChart;
