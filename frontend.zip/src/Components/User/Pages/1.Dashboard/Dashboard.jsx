import React from 'react'
import './Dashboard.css'
import BarChart from './CHARTS/BARCHART/Barchart'
import UserCountChart from './CHARTS/LineChart/LineCharts'
import { Carddetails } from './CHARTS/CARDS/Carddetails (3)'
import LineChart from './CHARTS/LineChart/LineCharts'
import DoughnutChart from './CHARTS/LineChart/LineCharts'

const CampaignDashboard = () => {
  return (
    <div>
      <div className='charts_dashboard'>
        {/* <div><UserCountChart/></div> */}
        <div><DoughnutChart/></div>
        <div><BarChart /></div>
        <div><Carddetails/></div>
      </div>
    </div>


  )
}

export default CampaignDashboard
