import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../../../Utils/axiosInstance'; // Import the axiosInstance
import './CampaignDetails.css';

// Utility function to format dates
const formatDate = (dateString) => {
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

const CampaignDetails = ({ campaigns, onClose }) => {
  const [images, setImages] = useState([]);

  const fetchImages = async (campId, email_hash) => {
    try {
      const response = await axiosInstance.post('/admin/fetchbannerimage', { campId, email_hash });
      if (response.data.code === 200) {
        setImages(response.data.data); // Access the 'data' property
      } else {
        console.error('Error fetching images:', response.data.message);
      }
    } catch (error) {
      console.error('API error:', error);
    }
  };

  useEffect(() => {
    if (campaigns.length > 0) {
      const { campaign_id, email_hash } = campaigns[0];
      fetchImages(campaign_id, email_hash);
    }
  }, [campaigns]);

  return (
    <div className="campaign-details">
      <button className="close-button" onClick={onClose}>X</button>
      <h2>Campaign Details</h2>
      {campaigns.length > 0 ? (
        <div className="campaign-list">
          {campaigns.map((campaign, index) => (
            <div key={index} className="campaign-card">
              {images[index] && images[index].data && (
                <img
                  src={`data:${images[index].contentType};base64,${images[index].data.$binary.base64}`}
                  alt={campaign.campaign_title}
                  className="campaign-image"
                />
              )}
              <div className="campaign-info">
                <h3>{campaign.campaign_title}</h3>
                <p>{campaign.campaign_description}</p>
                <p><strong>Type:</strong> {campaign.campaign_type}</p>
                <p><strong>Address:</strong> {campaign.campaign_address}</p>
                <p><strong>Start Date:</strong> {formatDate(campaign.start_date)}</p>
                <p><strong>End Date:</strong> {formatDate(campaign.end_date)}</p>
                <p><strong>Status:</strong> {campaign.status}</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p>No campaigns available.</p>
      )}
    </div>
  );
};

export default CampaignDetails;
