import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';
import './Queries.css'; // Importing the CSS file for styles

const Queries = () => {
  const [queries, setQueries] = useState([]); // Initialize as an empty array
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchQueries = async () => {
      try {
        const response = await axiosInstance.get('/admin/allqueries'); // API endpoint to fetch queries
        console.log(response.data); // Log the response to inspect its structure
        // Ensure response data is an array before setting state
        if (Array.isArray(response.data.data)) {
          setQueries(response.data.data); // Set the queries array
        } else {
          setError('Unexpected response format'); // Handle unexpected formats
        }
      } catch (err) {
        setError('Error fetching queries'); // Catch any errors from the request
      } finally {
        setLoading(false); // Stop loading state
      }
    };

    fetchQueries();
  }, []);

  // Loading and error handling
  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div>
      <h1>Queries</h1>
      <table className="queries-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th> {/* Changed from Mobile Number to Email */}
            <th>Message</th>
          </tr>
        </thead>
        <tbody>
          {queries.map(query => (
            <tr key={query.name}> {/* Use name as the key */}
              <td>{query.name}</td>
              <td>{query.email ? query.email : 'No email provided'}</td> {/* Changed to query.email */}
              <td>{query.message}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Queries;
