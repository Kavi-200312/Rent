import React from 'react'
import { Link } from 'react-router-dom'
import Campaign from '../../../User/Campaign'

const Inbox = () => {
  return (
    <div>
      Inbox
      <Campaign/>
      <Link to='/admin/inbox/campaignform'>Campaign form</Link>
    </div>
  )
}

export default Inbox
