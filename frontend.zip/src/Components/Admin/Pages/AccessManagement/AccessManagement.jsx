import React from 'react'

const AccessManagement = () => {
  return (
    <div>
      AccessManagement
    </div>
  )
}

export default AccessManagement
